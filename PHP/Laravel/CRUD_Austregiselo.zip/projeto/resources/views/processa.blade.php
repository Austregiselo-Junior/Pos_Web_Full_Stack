<p>Olá seu dados:</p>

<p>Nome: {{ $nome}}</p>
<p>Email: {{ $email}}</p>