<p>Olá seu dados:</p>

<p>Nome: <?php echo e($nome); ?></p>
<p>Email: <?php echo e($email); ?></p><?php /**PATH C:\xampp\htdocs\projeto\resources\views/processa.blade.php ENDPATH**/ ?>