<html>
    <body>
        <form method='POST' action=/contato>
           <?php echo e(csrf_field()); ?>

            Nome: <input type='text'  name='nome' />
            email <input type='text' name='email' />
            <input type='submit' value='enviar'/>
        </form> 
    </body>
</html><?php /**PATH C:\xampp\htdocs\projeto\resources\views/contato.blade.php ENDPATH**/ ?>